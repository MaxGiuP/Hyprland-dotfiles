#!/usr/bin/env sh
# Anything you want restarted/refreshed
notify-send "Resumed"
# /usr/bin/sh -lc "~/.config/hypr/custom/scripts/restart_quickshell.sh"

# restart_quickshell.sh
# Chiude tutti i processi quickshell e qs, poi avvia "qs -c ii".
